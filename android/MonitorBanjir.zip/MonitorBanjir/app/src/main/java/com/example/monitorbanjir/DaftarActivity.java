package com.example.monitorbanjir;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class DaftarActivity extends AppCompatActivity {
    private Intent intent;
    private RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar);

        Button kembali = findViewById(R.id.kembali);
        Button daftar = findViewById(R.id.daftar);

        daftar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prosesDaftar();
            }
        });

        kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(DaftarActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void prosesDaftar() {
        EditText email = findViewById(R.id.email);
        EditText name = findViewById(R.id.name);
        EditText password = findViewById(R.id.password);
        EditText username = findViewById(R.id.username);
        EditText url = findViewById(R.id.url);

        String get = "/banjir/public/api/register";
        String urlPost = url.getText() + get;

        requestQueue = Volley.newRequestQueue(this);

        JSONObject postData = new JSONObject();
        try {
            postData.put("email", email.getText().toString());
            postData.put("username", username.getText().toString());
            postData.put("name", name.getText().toString());
            postData.put("password", password.getText().toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }


        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, urlPost, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            int daftar = response.getInt("daftar");
                            String pesan = response.getString("pesan");

                            if(daftar == 1) {
                                intent = new Intent(DaftarActivity.this, LoginActivity.class);
                                intent.putExtra("pesan", pesan);
                                startActivity(intent);
                                finish();
                            }else {
                                Toast.makeText(getApplicationContext(), pesan, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), "Terjadi kesalahan", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Response Error", Toast.LENGTH_SHORT).show();
                    }
                });

        requestQueue.add(request);


    }



}