package com.example.monitorbanjir;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class DataActivity extends AppCompatActivity {
    private String name, posisi, email, token_sensor,url;
    private String VKetinggian, VKet;
    private Integer id;
    private Intent intent;
    private RequestQueue requestQueue;
    private Timer timer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        IntentCheck();
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                ambilData();
            }
        }, 0, 3000);


        Button kembali = findViewById(R.id.kembali);

        kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(DataActivity.this, MainActivity.class);
                intent.putExtra("id", String.valueOf(id));
                intent.putExtra("name", name);
                intent.putExtra("posisi", posisi);
                intent.putExtra("token_sensor", token_sensor);
                intent.putExtra("email", email);
                intent.putExtra("url", url);
                startActivity(intent);
                finish();
            }
        });

    }


    private void ambilData() {

        String get = "/banjir/public/api/android/"+token_sensor+"/data";
        String urlPost = url + get;

        requestQueue = Volley.newRequestQueue(this);


        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, urlPost, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                           VKetinggian = response.getString("ketinggian");
                           VKet = response.getString("ket");
                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), "Terjadi kesalahan", Toast.LENGTH_SHORT).show();
                        }

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                TextView ketinggian = findViewById(R.id.ketinggian);
                                TextView ket = findViewById(R.id.ket);

                                ketinggian.setText(VKetinggian.toString() + "Cm");
                                ket.setText(VKet.toString());

                                if(VKet.equals("sedang")){
                                    ketinggian.setTextColor(getResources().getColor(R.color.warning));
                                    ket.setTextColor(getResources().getColor(R.color.warning));
                                    ket.setText("Waspada".toUpperCase());
                                }else if(VKet.equals("tinggi")){
                                    ketinggian.setTextColor(getResources().getColor(R.color.red));
                                    ket.setTextColor(getResources().getColor(R.color.red));
                                    ket.setText("Bahaya".toUpperCase());
                                }else if(VKet.equals("normal")) {
                                    ketinggian.setTextColor(getResources().getColor(R.color.success));
                                    ket.setTextColor(getResources().getColor(R.color.success));
                                    ket.setText("Normal".toUpperCase());
                                }
                            }
                        });
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Response Error", Toast.LENGTH_SHORT).show();
                    }
                });

        requestQueue.add(request);


    }



    private void IntentCheck() {
        intent = getIntent();
        if (intent != null) {
//            if(intent.hasExtra("id")){
//                Toast.makeText(getApplicationContext(), intent.getStringExtra("id"), Toast.LENGTH_SHORT).show();
//            }
            id = Integer.parseInt(intent.getStringExtra("id"));
            name = intent.getStringExtra("name");
            posisi = intent.getStringExtra("posisi");
            token_sensor = intent.getStringExtra("token_sensor");
            email = intent.getStringExtra("email");
            url = intent.getStringExtra("url");


        } else {
            intent = new Intent(DataActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    }
}