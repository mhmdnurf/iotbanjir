package com.example.monitorbanjir;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class HistoriActivity extends AppCompatActivity {
    private String name, posisi, email, token_sensor,url;
    private Integer id;
    private Intent intent;
    private RecyclerView recyclerView;
    private LogAdapter logAdapter;
    private List<LogItem> logList;
    private RequestQueue requestQueue;
    private Timer timer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_histori);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        IntentCheck();

        logList = new ArrayList<>();
        logAdapter = new LogAdapter(logList);
        recyclerView.setAdapter(logAdapter);

        requestQueue = Volley.newRequestQueue(this);
        timer = new Timer();

        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                fetchData();
            }
        }, 0, 4000);



        Button kembali = findViewById(R.id.kembali);

        kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(HistoriActivity.this, MainActivity.class);
                intent.putExtra("id", String.valueOf(id));
                intent.putExtra("name", name);
                intent.putExtra("posisi", posisi);
                intent.putExtra("token_sensor", token_sensor);
                intent.putExtra("email", email);
                intent.putExtra("url", url);
                startActivity(intent);
                finish();
            }
        });

    }




    private void IntentCheck() {
        intent = getIntent();
        if (intent != null) {
//            if(intent.hasExtra("id")){
//                Toast.makeText(getApplicationContext(), intent.getStringExtra("id"), Toast.LENGTH_SHORT).show();
//            }
            id = Integer.parseInt(intent.getStringExtra("id"));
            name = intent.getStringExtra("name");
            posisi = intent.getStringExtra("posisi");
            token_sensor = intent.getStringExtra("token_sensor");
            email = intent.getStringExtra("email");
            url = intent.getStringExtra("url");


        } else {
            intent = new Intent(HistoriActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    }



    private void fetchData() {
        String get = "/banjir/public/api/android/"+token_sensor+"/logs";
        String urlPost = url + get;
        RequestQueue requestQueue = Volley.newRequestQueue(this);


        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, urlPost, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        logList.clear();
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                JSONObject jsonObject = response.getJSONObject(i);
                                String ketinggian = String.valueOf(jsonObject.getInt("ketinggian"))+"Cm";
                                String ket = jsonObject.getString("ket");
                                String tanggal = jsonObject.getString("tanggal")+" "+jsonObject.getString("jam");
                                logList.add(new LogItem(ketinggian, ket, tanggal));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                logAdapter.notifyDataSetChanged();
                            }
                        });
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });

        requestQueue.add(jsonArrayRequest);



    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (timer != null) {
            timer.cancel();
        }
    }

}