package com.example.monitorbanjir;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class LogAdapter extends RecyclerView.Adapter<LogAdapter.LogViewHolder> {

    private List<LogItem> logList;

    public LogAdapter(List<LogItem> logList) {
        this.logList = logList;
    }

    @NonNull
    @Override
    public LogViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_log, parent, false);
        return new LogViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LogViewHolder holder, int position) {
        LogItem logItem = logList.get(position);
        holder.textViewKeterangan.setText(logItem.getKet());
        holder.textViewKetinggian.setText(logItem.getKetinggian());
        holder.textViewTanggal.setText(logItem.getTanggal());
    }

    @Override
    public int getItemCount() {
        return logList.size();
    }

    public static class LogViewHolder extends RecyclerView.ViewHolder {
        TextView textViewKeterangan, textViewKetinggian, textViewTanggal;

        public LogViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewKeterangan = itemView.findViewById(R.id.textViewKeterangan);
            textViewKetinggian = itemView.findViewById(R.id.textViewKetinggian);
            textViewTanggal = itemView.findViewById(R.id.textViewTanggal);
        }
    }
}
