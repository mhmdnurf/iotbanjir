package com.example.monitorbanjir;

public class LogItem {
    private String ketinggian;
    private String ket;
    private String tanggal;

    public LogItem(String ketinggian, String ket, String tanggal) {
        this.ketinggian = ketinggian;
        this.ket = ket;
        this.tanggal = tanggal;
    }

    public String getKetinggian() {
        return ketinggian;
    }

    public String getKet() {
        return ket;
    }

    public String getTanggal() {
        return tanggal;
    }
}
