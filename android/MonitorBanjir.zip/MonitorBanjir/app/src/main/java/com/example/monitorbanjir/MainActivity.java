package com.example.monitorbanjir;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    private String name, posisi, email, token_sensor,url;
    private int id;
    private Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button data = findViewById(R.id.data);
        Button histori = findViewById(R.id.histori);
        Button pengaturan = findViewById(R.id.pengaturan);
        IntentCheck();


        Button logout = findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });


        pengaturan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(MainActivity.this, PengaturanActivity.class);
                intent.putExtra("id", String.valueOf(id));
                intent.putExtra("name", name);
                intent.putExtra("posisi", posisi);
                intent.putExtra("token_sensor", token_sensor);
                intent.putExtra("email", email);
                intent.putExtra("url", url);
                startActivity(intent);
                finish();
            }
        });

        histori.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(MainActivity.this, HistoriActivity.class);
                intent.putExtra("id", String.valueOf(id));
                intent.putExtra("name", name);
                intent.putExtra("posisi", posisi);
                intent.putExtra("token_sensor", token_sensor);
                intent.putExtra("email", email);
                intent.putExtra("url", url);
                startActivity(intent);
                finish();
            }
        });


        data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(MainActivity.this, DataActivity.class);
                intent.putExtra("id", String.valueOf(id));
                intent.putExtra("name", name);
                intent.putExtra("posisi", posisi);
                intent.putExtra("token_sensor", token_sensor);
                intent.putExtra("email", email);
                intent.putExtra("url", url);
                startActivity(intent);
                finish();
            }
        });






    }




    private void IntentCheck() {
        intent = getIntent();
        if (intent != null) {
            try {
                if(intent.hasExtra("pesan")){
                    String pesan = intent.getStringExtra("pesan");
                    Toast.makeText(getApplicationContext(), pesan, Toast.LENGTH_SHORT).show();
                }

                id = Integer.parseInt(intent.getStringExtra("id").toString());
                name = intent.getStringExtra("name");
                posisi = intent.getStringExtra("posisi");
                token_sensor = intent.getStringExtra("token_sensor");
                email = intent.getStringExtra("email");
                url = intent.getStringExtra("url");

                Button pengaturan = findViewById(R.id.pengaturan);
                if(posisi.equals("admin")) {
                    pengaturan.setVisibility(View.VISIBLE);
                }else {
                    pengaturan.setVisibility(View.GONE);
                }
            }catch (Exception e) {
                Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
            }


        } else {
            intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
    }


}