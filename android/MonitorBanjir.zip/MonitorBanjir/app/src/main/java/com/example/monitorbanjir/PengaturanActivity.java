package com.example.monitorbanjir;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Timer;
import java.util.TimerTask;

public class PengaturanActivity extends AppCompatActivity {
    private String name, posisi, email, token_sensor,url;
    private int ketinggianMax, waspada, bahaya, menit;
    private Integer id;
    private Intent intent;
    private RequestQueue requestQueue;
    private Timer timer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pengaturan);

        Button kembali = findViewById(R.id.kembali);

        kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(PengaturanActivity.this, MainActivity.class);
                intent.putExtra("id", String.valueOf(id));
                intent.putExtra("name", name);
                intent.putExtra("posisi", posisi);
                intent.putExtra("token_sensor", token_sensor);
                intent.putExtra("email", email);
                intent.putExtra("url", url);
                startActivity(intent);
                finish();
            }
        });



        IntentCheck();
        ambilData();

        Button update = findViewById(R.id.update);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               updateData();
               ambilData();
            }
        });


    }


    private void updateData() {

        String post = "/banjir/public/api/android/"+token_sensor+"/pengaturan";
        String urlPost = url + post;

        requestQueue = Volley.newRequestQueue(this);

        TextView ambilketinggianMax = findViewById(R.id.ketinggianMax);
        TextView ambilwaspada = findViewById(R.id.waspada);
        TextView ambilbahaya = findViewById(R.id.bahaya);
        TextView ambilmenit = findViewById(R.id.menit);

        JSONObject postData = new JSONObject();
        try {
            postData.put("ketinggianMax", ambilketinggianMax.getText().toString());
            postData.put("waspada", ambilwaspada.getText().toString());
            postData.put("bahaya", ambilbahaya.getText().toString());
            postData.put("menit", ambilmenit.getText().toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, urlPost, postData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            String pesan = response.getString("pesan");

                            Toast.makeText(getApplicationContext(), pesan, Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), "Terjadi kesalahan", Toast.LENGTH_SHORT).show();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Response Error", Toast.LENGTH_SHORT).show();
                    }
                });

        requestQueue.add(request);


    }

    private void ambilData() {

        String get = "/banjir/public/api/android/"+token_sensor+"/pengaturan";
        String urlPost = url + get;

        requestQueue = Volley.newRequestQueue(this);


        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, urlPost, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            ketinggianMax = response.getInt("ketinggianMax");
                            waspada = response.getInt("waspada");
                            bahaya = response.getInt("bahaya");
                            menit = response.getInt("menit");

                            TextView tampungketinggianMax = findViewById(R.id.ketinggianMax);
                            TextView tampungwaspada = findViewById(R.id.waspada);
                            TextView tampungbahaya = findViewById(R.id.bahaya);
                            TextView tampungmenit = findViewById(R.id.menit);

                            tampungketinggianMax.setText(String.valueOf(ketinggianMax));
                            tampungwaspada.setText(String.valueOf(waspada));
                            tampungbahaya.setText(String.valueOf(bahaya));
                            tampungmenit.setText(String.valueOf(menit));
                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), "Terjadi kesalahan", Toast.LENGTH_SHORT).show();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Response Error", Toast.LENGTH_SHORT).show();
                    }
                });

        requestQueue.add(request);


    }

    private void IntentCheck() {
        intent = getIntent();
        if (intent != null) {
//            if(intent.hasExtra("id")){
//                Toast.makeText(getApplicationContext(), intent.getStringExtra("id"), Toast.LENGTH_SHORT).show();
//            }
            id = Integer.parseInt(intent.getStringExtra("id"));
            name = intent.getStringExtra("name");
            posisi = intent.getStringExtra("posisi");
            token_sensor = intent.getStringExtra("token_sensor");
            email = intent.getStringExtra("email");
            url = intent.getStringExtra("url");


        } else {
            intent = new Intent(PengaturanActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    }



}